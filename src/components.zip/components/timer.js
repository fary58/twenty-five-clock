import React, { useEffect, useState, useRef } from "react";
import store from "./store";
import { useSelector, useDispatch, refetch } from "react-redux";
import { formatTime } from "./helpers";
import { initial } from "./features/breaker/breakerSlice";
import { start } from "./features/session/sessionSlice";
import { setActual, startTime } from "./features/timer/timerSlice";

const Timer = (props) => {
  const [play, setPlay] = useState(
    JSON.parse(localStorage.getItem("timerStatus"))
  );
  const [currentTimer, setCurrentTimer] = useState("session");
  const sessionTimer = useSelector((state) => state.timer.value);
  const breakTimer = useSelector((state) => state.breaker.value);

  const dispatch = useDispatch();

  let data = useRef();

  useEffect(() => {});

  const startTimer = (type) => {
    const currentCounterTime = currentTimer == "session" ? sessionTimer : breakTimer;
    var countDownDate = new Date().getTime() + sessionTimer * 1000;
    if (type == "start") {
      data.id = setInterval(function () {
        // localStorage.setItem("timerStatus", JSON.stringify(true));
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate - now;
        // console.log(distance);
        let newSession = dispatch(setActual(Math.floor(distance / 1000)));
      }, 1000);
    } else {
      localStorage.clear();
      // localStorage.setItem("timerStatus", JSON.stringify(false));
      setPlay(false);
      clearInterval(data.id);
      // document.getElementById("demo").innerHTML = "EXPIRED";
    }
  };

  function Dispatch(amount) {
    // if (watch) {
      dispatch(initial());
      dispatch(start());
      dispatch(startTime());
      // dispatch(setActual(amount));
    // }
  }

  return (
    <>
      {currentTimer == "session" ? (
        <>
          <div id="timer-label">Session</div>
          <div id="time-left">{formatTime(sessionTimer)}</div>
        </>
      ) : (
        <>
          <div id="timer-label">Break</div>
          <div id="time-left">{formatTime(breakTimer)}</div>
        </>
      )}

      {!play ? (
        <div
          id="start_stop"
          onClick={() => startTimer("start", setPlay(true))}
        >
          <i className="fa-solid fa-play"></i>
        </div>
      ) : (
        <div id="start_stop" onClick={() => startTimer("pause")}>
          <i className="fa-solid fa-pause"></i>
        </div>
      )}

      {/* <div id="reset" onClick={Dispatch}>
        Reset
      </div> */}
    </>
  );
};

export default Timer;
